import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.LocalDateTime;

public class TicketDAO {

    // ==========================================
    // 1. TẠO VÉ KHI XE VÀO
    // ==========================================

    public boolean createTicket(int vehicleId, String paymentType) {

        String sql = "INSERT INTO tickets " +
                "(vehicle_id, entry_time, payment_type) " +
                "VALUES (?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, vehicleId);
            stmt.setTimestamp(
                    2,
                    Timestamp.valueOf(LocalDateTime.now())
            );
            stmt.setString(3, paymentType);

            return stmt.executeUpdate() > 0;

        } catch (Exception e) {

            System.out.println(
                    "Loi tao ve: " + e.getMessage()
            );

            return false;
        }
    }


    // ==========================================
    // 2. TÌM VÉ ĐANG HOẠT ĐỘNG
    // ==========================================

    public Ticket findActiveTicket(int vehicleId) {

        String sql =
                "SELECT * FROM tickets " +
                        "WHERE vehicle_id = ? " +
                        "AND exit_time IS NULL " +
                        "ORDER BY entry_time DESC LIMIT 1";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, vehicleId);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                Ticket ticket = new Ticket();

                ticket.setId(rs.getInt("id"));
                ticket.setVehicleId(
                        rs.getInt("vehicle_id")
                );

                Timestamp entry =
                        rs.getTimestamp("entry_time");

                if (entry != null) {
                    ticket.setEntryTime(
                            entry.toLocalDateTime()
                    );
                }

                Timestamp exit =
                        rs.getTimestamp("exit_time");

                if (exit != null) {
                    ticket.setExitTime(
                            exit.toLocalDateTime()
                    );
                }

                ticket.setFee(
                        rs.getDouble("fee")
                );

                ticket.setPaymentType(
                        rs.getString("payment_type")
                );

                return ticket;
            }

        } catch (Exception e) {

            System.out.println(
                    "Loi tim ve: " + e.getMessage()
            );
        }

        return null;
    }


    // ==========================================
    // 3. TÍNH PHÍ THEO GIỜ
    // ==========================================

    public double calculateHourlyFee(
            LocalDateTime entryTime,
            LocalDateTime exitTime) {

        long minutes =
                Duration.between(
                        entryTime,
                        exitTime
                ).toMinutes();

        double pricePerHour = 10000;

        long hours =
                (long) Math.ceil(minutes / 60.0);

        if (hours < 1) {
            hours = 1;
        }

        return hours * pricePerHour;
    }


    // ==========================================
    // 4. TÍNH PHÍ THEO NGÀY
    // ==========================================

    public double calculateDailyFee(
            LocalDateTime entryTime,
            LocalDateTime exitTime) {

        long minutes =
                Duration.between(
                        entryTime,
                        exitTime
                ).toMinutes();

        double pricePerDay = 100000;

        long days =
                (long) Math.ceil(
                        minutes / (24.0 * 60.0)
                );

        if (days < 1) {
            days = 1;
        }

        return days * pricePerDay;
    }


    // ==========================================
    // 5. ĐÓNG VÉ
    // ==========================================

    public boolean closeTicket(
            int ticketId,
            LocalDateTime exitTime,
            double fee) {

        String sql =
                "UPDATE tickets " +
                        "SET exit_time = ?, fee = ? " +
                        "WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt =
                     conn.prepareStatement(sql)) {

            stmt.setTimestamp(
                    1,
                    Timestamp.valueOf(exitTime)
            );

            stmt.setDouble(2, fee);

            stmt.setInt(3, ticketId);

            return stmt.executeUpdate() > 0;

        } catch (Exception e) {

            System.out.println(
                    "Loi dong ve: " + e.getMessage()
            );

            return false;
        }
    }


    // ==========================================
    // 6. XEM LỊCH SỬ VÉ
    // ==========================================

    public void showTicketHistory() {

        String sql =
                "SELECT t.id, v.license_plate, " +
                        "t.entry_time, t.exit_time, " +
                        "t.payment_type, t.fee " +
                        "FROM tickets t " +
                        "JOIN vehicles v " +
                        "ON t.vehicle_id = v.id " +
                        "ORDER BY t.id DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt =
                     conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            System.out.println();
            System.out.println(
                    "=========================================================================="
            );

            System.out.println(
                    "                         LICH SU VE XE"
            );

            System.out.println(
                    "=========================================================================="
            );

            System.out.printf(
                    "%-5s %-15s %-20s %-20s %-12s %-15s%n",
                    "ID",
                    "Bien so",
                    "Gio vao",
                    "Gio ra",
                    "Hinh thuc",
                    "So tien"
            );

            System.out.println(
                    "--------------------------------------------------------------------------"
            );

            boolean hasData = false;

            while (rs.next()) {

                hasData = true;

                int id = rs.getInt("id");

                String licensePlate =
                        rs.getString("license_plate");

                Timestamp entry =
                        rs.getTimestamp("entry_time");

                Timestamp exit =
                        rs.getTimestamp("exit_time");

                String paymentType =
                        rs.getString("payment_type");

                double fee =
                        rs.getDouble("fee");

                String entryText =
                        entry != null
                                ? entry.toLocalDateTime().toString()
                                : "";

                String exitText =
                        exit != null
                                ? exit.toLocalDateTime().toString()
                                : "Dang trong bai";

                String typeText;

                if ("day".equalsIgnoreCase(paymentType)) {
                    typeText = "Theo ngay";
                } else {
                    typeText = "Theo gio";
                }

                System.out.printf(
                        "%-5d %-15s %-20s %-20s %-12s %,.0f VND%n",
                        id,
                        licensePlate,
                        entryText,
                        exitText,
                        typeText,
                        fee
                );
            }

            if (!hasData) {

                System.out.println(
                        "Chua co lich su ve xe."
                );
            }

            System.out.println(
                    "=========================================================================="
            );

        } catch (Exception e) {

            System.out.println(
                    "Loi hien thi lich su ve: "
                            + e.getMessage()
            );
        }
    }
}