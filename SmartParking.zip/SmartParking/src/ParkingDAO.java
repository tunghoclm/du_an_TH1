import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ParkingDAO {

    // Tổng số chỗ đỗ trong bãi
    private final int TOTAL_SLOTS = 20;


    // ==========================================
    // 1. TÌM XE THEO BIỂN SỐ
    // ==========================================

    public Vehicle findVehicle(String licensePlate) {

        String sql =
                "SELECT * FROM vehicles " +
                        "WHERE license_plate = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt =
                     conn.prepareStatement(sql)) {

            stmt.setString(1, licensePlate);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                Vehicle vehicle = new Vehicle();

                vehicle.setId(
                        rs.getInt("id")
                );

                vehicle.setLicensePlate(
                        rs.getString("license_plate")
                );

                vehicle.setVehicleType(
                        rs.getString("vehicle_type")
                );

                vehicle.setOwnerName(
                        rs.getString("owner_name")
                );

                return vehicle;
            }

        } catch (Exception e) {

            System.out.println(
                    "Loi tim xe: " + e.getMessage()
            );
        }

        return null;
    }


    // ==========================================
    // 2. THÊM XE
    // ==========================================

    public boolean addVehicle(Vehicle vehicle) {

        String sql =
                "INSERT INTO vehicles " +
                        "(license_plate, vehicle_type, owner_name) " +
                        "VALUES (?, ?, ?)";

        try (Connection conn =
                     DBConnection.getConnection();
             PreparedStatement stmt =
                     conn.prepareStatement(sql)) {

            stmt.setString(
                    1,
                    vehicle.getLicensePlate()
            );

            stmt.setString(
                    2,
                    vehicle.getVehicleType()
            );

            stmt.setString(
                    3,
                    vehicle.getOwnerName()
            );

            return stmt.executeUpdate() > 0;

        } catch (Exception e) {

            System.out.println(
                    "Loi them xe: " + e.getMessage()
            );

            return false;
        }
    }


    // ==========================================
    // 3. HIỂN THỊ TẤT CẢ XE
    // ==========================================

    public void showAllVehicles() {

        String sql =
                "SELECT * FROM vehicles ORDER BY id";

        try (Connection conn =
                     DBConnection.getConnection();
             PreparedStatement stmt =
                     conn.prepareStatement(sql);
             ResultSet rs =
                     stmt.executeQuery()) {

            System.out.println();

            System.out.println(
                    "============================================================"
            );

            System.out.println(
                    "                    DANH SACH XE"
            );

            System.out.println(
                    "============================================================"
            );

            System.out.printf(
                    "%-5s %-18s %-15s %-25s%n",
                    "ID",
                    "Bien so",
                    "Loai xe",
                    "Chu xe"
            );

            System.out.println(
                    "------------------------------------------------------------"
            );

            boolean hasData = false;

            while (rs.next()) {

                hasData = true;

                System.out.printf(
                        "%-5d %-18s %-15s %-25s%n",

                        rs.getInt("id"),

                        rs.getString(
                                "license_plate"
                        ),

                        rs.getString(
                                "vehicle_type"
                        ),

                        rs.getString(
                                "owner_name"
                        )
                );
            }

            if (!hasData) {

                System.out.println(
                        "Chua co xe trong he thong."
                );
            }

            System.out.println(
                    "============================================================"
            );

        } catch (Exception e) {

            System.out.println(
                    "Loi hien thi danh sach xe: "
                            + e.getMessage()
            );
        }
    }


    // ==========================================
    // 4. ĐẾM XE ĐANG TRONG BÃI
    // ==========================================

    public int countVehiclesInParking() {

        String sql =
                "SELECT COUNT(*) AS total " +
                        "FROM tickets " +
                        "WHERE exit_time IS NULL";

        try (Connection conn =
                     DBConnection.getConnection();
             PreparedStatement stmt =
                     conn.prepareStatement(sql);
             ResultSet rs =
                     stmt.executeQuery()) {

            if (rs.next()) {

                return rs.getInt("total");
            }

        } catch (Exception e) {

            System.out.println(
                    "Loi dem xe trong bai: "
                            + e.getMessage()
            );
        }

        return 0;
    }


    // ==========================================
    // 5. HIỂN THỊ TRẠNG THÁI CHỖ ĐỖ
    // ==========================================

    public void showParkingSlots() {

        int vehiclesInParking =
                countVehiclesInParking();

        int emptySlots =
                TOTAL_SLOTS - vehiclesInParking;

        if (emptySlots < 0) {

            emptySlots = 0;
        }

        System.out.println();

        System.out.println(
                "=========================================="
        );

        System.out.println(
                "          TRANG THAI BAI DO XE"
        );

        System.out.println(
                "=========================================="
        );

        System.out.println(
                "Tong so cho: "
                        + TOTAL_SLOTS
        );

        System.out.println(
                "Dang co xe: "
                        + vehiclesInParking
        );

        System.out.println(
                "Con trong: "
                        + emptySlots
        );

        System.out.println(
                "------------------------------------------"
        );


        for (int i = 1;
             i <= TOTAL_SLOTS;
             i++) {

            String slot =
                    String.format(
                            "A%02d",
                            i
                    );

            if (i <= vehiclesInParking) {

                System.out.println(
                        slot + " - CO XE"
                );

            } else {

                System.out.println(
                        slot + " - TRONG"
                );
            }
        }

        System.out.println(
                "=========================================="
        );
    }


    // ==========================================
    // 6. THỐNG KÊ HỆ THỐNG
    // ==========================================

    public void showStatistics() {

        String sqlTotal =
                "SELECT COUNT(*) AS total " +
                        "FROM vehicles";


        String sqlInParking =
                "SELECT COUNT(*) AS total " +
                        "FROM tickets " +
                        "WHERE exit_time IS NULL";


        String sqlOutParking =
                "SELECT COUNT(*) AS total " +
                        "FROM tickets " +
                        "WHERE exit_time IS NOT NULL";


        String sqlRevenue =
                "SELECT COALESCE(SUM(fee), 0) AS revenue " +
                        "FROM tickets " +
                        "WHERE exit_time IS NOT NULL";


        int totalVehicles = 0;

        int vehiclesInParking = 0;

        int vehiclesOut = 0;

        double revenue = 0;


        try (Connection conn =
                     DBConnection.getConnection()) {


            // ------------------------------------------
            // Tổng số xe
            // ------------------------------------------

            try (PreparedStatement stmt =
                         conn.prepareStatement(
                                 sqlTotal
                         );

                 ResultSet rs =
                         stmt.executeQuery()) {

                if (rs.next()) {

                    totalVehicles =
                            rs.getInt("total");
                }
            }


            // ------------------------------------------
            // Xe đang trong bãi
            // ------------------------------------------

            try (PreparedStatement stmt =
                         conn.prepareStatement(
                                 sqlInParking
                         );

                 ResultSet rs =
                         stmt.executeQuery()) {

                if (rs.next()) {

                    vehiclesInParking =
                            rs.getInt("total");
                }
            }


            // ------------------------------------------
            // Xe đã ra
            // ------------------------------------------

            try (PreparedStatement stmt =
                         conn.prepareStatement(
                                 sqlOutParking
                         );

                 ResultSet rs =
                         stmt.executeQuery()) {

                if (rs.next()) {

                    vehiclesOut =
                            rs.getInt("total");
                }
            }


            // ------------------------------------------
            // Doanh thu
            // ------------------------------------------

            try (PreparedStatement stmt =
                         conn.prepareStatement(
                                 sqlRevenue
                         );

                 ResultSet rs =
                         stmt.executeQuery()) {

                if (rs.next()) {

                    revenue =
                            rs.getDouble("revenue");
                }
            }


            // ------------------------------------------
            // HIỂN THỊ
            // ------------------------------------------

            System.out.println();

            System.out.println(
                    "=========================================="
            );

            System.out.println(
                    "          THONG KE BAI DO XE"
            );

            System.out.println(
                    "=========================================="
            );

            System.out.printf(
                    "Tong so xe:          %d xe%n",
                    totalVehicles
            );

            System.out.printf(
                    "Xe dang trong bai:   %d xe%n",
                    vehiclesInParking
            );

            System.out.printf(
                    "Xe da roi bai:       %d xe%n",
                    vehiclesOut
            );

            System.out.printf(
                    "Doanh thu:           %,.0f VND%n",
                    revenue
            );

            System.out.println(
                    "=========================================="
            );

        } catch (Exception e) {

            System.out.println(
                    "Loi thong ke: "
                            + e.getMessage()
            );
        }
    }
}