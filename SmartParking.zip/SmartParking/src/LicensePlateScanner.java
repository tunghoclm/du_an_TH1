import java.util.Scanner;

public class LicensePlateScanner {

    // ==========================================
    // MÔ PHỎNG CAMERA NHẬN DIỆN BIỂN SỐ
    // ==========================================

    public String scanLicensePlate(Scanner sc) {

        System.out.println();

        System.out.println(
                "================================"
        );

        System.out.println(
                "      CAMERA NHAN DIEN BIEN SO"
        );

        System.out.println(
                "================================"
        );

        System.out.println(
                "Dang khoi dong camera..."
        );

        System.out.println(
                "Dang quet phuong tien..."
        );

        System.out.println(
                "Da phat hien phuong tien!"
        );

        System.out.println();

        System.out.print(
                "Bien so nhan dien duoc: "
        );

        String licensePlate =
                sc.nextLine();

        return licensePlate
                .trim()
                .toUpperCase();
    }
}