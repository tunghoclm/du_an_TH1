import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Camera / cảm biến nhận diện biển số
        LicensePlateScanner scanner =
                new LicensePlateScanner();


        // ==========================================
        // ĐĂNG NHẬP
        // ==========================================

        System.out.println(
                "================================"
        );

        System.out.println(
                "         SMART PARKING"
        );

        System.out.println(
                "            DANG NHAP"
        );

        System.out.println(
                "================================"
        );


        System.out.print(
                "Username: "
        );

        String username =
                sc.nextLine();


        System.out.print(
                "Password: "
        );

        String password =
                sc.nextLine();


        UserDAO userDAO =
                new UserDAO();


        User user =
                userDAO.login(
                        username,
                        password
                );


        // ==========================================
        // KIỂM TRA ĐĂNG NHẬP
        // ==========================================

        if (user == null) {

            System.out.println();

            System.out.println(
                    "Dang nhap that bai!"
            );

            System.out.println(
                    "Sai username hoac password."
            );

            sc.close();

            return;
        }


        System.out.println();

        System.out.println(
                "Dang nhap thanh cong!"
        );

        System.out.println(
                "Xin chao: "
                        + user.getUsername()
        );

        System.out.println(
                "Quyen: "
                        + user.getRole()
        );


        // ==========================================
        // KHỞI TẠO DAO
        // ==========================================

        ParkingDAO parkingDAO =
                new ParkingDAO();

        TicketDAO ticketDAO =
                new TicketDAO();


        // ==========================================
        // MENU
        // ==========================================

        int choice;


        do {

            System.out.println();

            System.out.println(
                    "================================"
            );

            System.out.println(
                    "       QUAN LY BAI DO XE"
            );

            System.out.println(
                    "================================"
            );

            System.out.println(
                    "1. Xe vao bai"
            );

            System.out.println(
                    "2. Tim xe theo bien so"
            );

            System.out.println(
                    "3. Hien thi tat ca xe"
            );

            System.out.println(
                    "4. Xe ra bai"
            );

            System.out.println(
                    "5. Xem lich su ve xe"
            );

            System.out.println(
                    "6. Xem trang thai cho do"
            );

            System.out.println(
                    "7. Tim xe bang camera"
            );

            System.out.println(
                    "8. Thong ke he thong"
            );

            System.out.println(
                    "0. Dang xuat"
            );

            System.out.println(
                    "================================"
            );


            System.out.print(
                    "Chon chuc nang: "
            );


            choice =
                    sc.nextInt();

            sc.nextLine();


            // ==========================================
            // 1. XE VÀO BÃI
            // ==========================================

            if (choice == 1) {

                System.out.println();

                System.out.println(
                        "================================"
                );

                System.out.println(
                        "          XE VAO BAI"
                );

                System.out.println(
                        "================================"
                );


                // Camera nhận diện biển số
                String licensePlate =
                        scanner.scanLicensePlate(sc);


                // Tìm xe
                Vehicle vehicle =
                        parkingDAO.findVehicle(
                                licensePlate
                        );


                // ==========================================
                // KIỂM TRA XE ĐANG TRONG BÃI
                // ==========================================

                if (vehicle != null) {

                    Ticket activeTicket =
                            ticketDAO.findActiveTicket(
                                    vehicle.getId()
                            );


                    if (activeTicket != null) {

                        System.out.println();

                        System.out.println(
                                "Xe nay dang o trong bai!"
                        );

                        System.out.println(
                                "Khong the tao them ve."
                        );

                        continue;
                    }
                }


                // ==========================================
                // XE CHƯA CÓ TRONG DATABASE
                // ==========================================

                if (vehicle == null) {

                    System.out.println();

                    System.out.println(
                            "Xe chua co trong he thong."
                    );

                    System.out.println(
                            "Tien hanh dang ky xe."
                    );


                    System.out.print(
                            "Loai xe: "
                    );

                    String vehicleType =
                            sc.nextLine();


                    System.out.print(
                            "Chu xe: "
                    );

                    String ownerName =
                            sc.nextLine();


                    vehicle =
                            new Vehicle();


                    vehicle.setLicensePlate(
                            licensePlate
                    );


                    vehicle.setVehicleType(
                            vehicleType
                    );


                    vehicle.setOwnerName(
                            ownerName
                    );


                    boolean added =
                            parkingDAO.addVehicle(
                                    vehicle
                            );


                    if (!added) {

                        System.out.println();

                        System.out.println(
                                "Khong the them xe!"
                        );

                        continue;
                    }


                    vehicle =
                            parkingDAO.findVehicle(
                                    licensePlate
                            );


                    if (vehicle == null) {

                        System.out.println();

                        System.out.println(
                                "Khong tim thay xe!"
                        );

                        continue;
                    }
                }


                // ==========================================
                // CHỌN HÌNH THỨC TÍNH PHÍ
                // ==========================================

                System.out.println();

                System.out.println(
                        "Chon hinh thuc tinh phi:"
                );

                System.out.println(
                        "1. Theo gio"
                );

                System.out.println(
                        "2. Theo ngay"
                );


                System.out.print(
                        "Lua chon: "
                );


                int paymentChoice =
                        sc.nextInt();

                sc.nextLine();


                String paymentType;


                if (paymentChoice == 2) {

                    paymentType =
                            "day";

                } else {

                    paymentType =
                            "hour";
                }


                // ==========================================
                // TẠO VÉ
                // ==========================================

                boolean ticketCreated =
                        ticketDAO.createTicket(
                                vehicle.getId(),
                                paymentType
                        );


                if (ticketCreated) {

                    System.out.println();

                    System.out.println(
                            "================================"
                    );

                    System.out.println(
                            "       XE VAO THANH CONG"
                    );

                    System.out.println(
                            "================================"
                    );


                    System.out.println(
                            "Bien so: "
                                    + vehicle.getLicensePlate()
                    );


                    System.out.println(
                            "Loai xe: "
                                    + vehicle.getVehicleType()
                    );


                    System.out.println(
                            "Chu xe: "
                                    + vehicle.getOwnerName()
                    );


                    System.out.println(
                            "Hinh thuc tinh phi: "
                                    + paymentType
                    );


                    System.out.println(
                            "Da tao ve xe!"
                    );


                } else {

                    System.out.println();

                    System.out.println(
                            "Khong the tao ve xe!"
                    );
                }
            }


            // ==========================================
            // 2. TÌM XE THEO BIỂN SỐ
            // ==========================================

            else if (choice == 2) {

                System.out.println();

                System.out.println(
                        "================================"
                );

                System.out.println(
                        "             TIM XE"
                );

                System.out.println(
                        "================================"
                );


                System.out.print(
                        "Nhap bien so xe: "
                );


                String licensePlate =
                        sc.nextLine();


                Vehicle vehicle =
                        parkingDAO.findVehicle(
                                licensePlate
                        );


                if (vehicle != null) {

                    System.out.println();

                    System.out.println(
                            "Tim thay xe!"
                    );


                    System.out.println(
                            "ID: "
                                    + vehicle.getId()
                    );


                    System.out.println(
                            "Bien so: "
                                    + vehicle.getLicensePlate()
                    );


                    System.out.println(
                            "Loai xe: "
                                    + vehicle.getVehicleType()
                    );


                    System.out.println(
                            "Chu xe: "
                                    + vehicle.getOwnerName()
                    );


                    Ticket activeTicket =
                            ticketDAO.findActiveTicket(
                                    vehicle.getId()
                            );


                    if (activeTicket != null) {

                        System.out.println(
                                "Trang thai: DANG O TRONG BAI"
                        );


                        System.out.println(
                                "Thoi gian vao: "
                                        + activeTicket.getEntryTime()
                        );

                    } else {

                        System.out.println(
                                "Trang thai: KHONG O TRONG BAI"
                        );
                    }


                } else {

                    System.out.println();

                    System.out.println(
                            "Khong tim thay xe!"
                    );
                }
            }


            // ==========================================
            // 3. HIỂN THỊ TẤT CẢ XE
            // ==========================================

            else if (choice == 3) {

                parkingDAO.showAllVehicles();
            }


            // ==========================================
            // 4. XE RA
            // ==========================================

            else if (choice == 4) {

                System.out.println();

                System.out.println(
                        "================================"
                );

                System.out.println(
                        "            XE RA BAI"
                );

                System.out.println(
                        "================================"
                );


                // Camera nhận diện biển số
                String licensePlate =
                        scanner.scanLicensePlate(sc);


                Vehicle vehicle =
                        parkingDAO.findVehicle(
                                licensePlate
                        );


                if (vehicle == null) {

                    System.out.println();

                    System.out.println(
                            "Khong tim thay xe!"
                    );

                    continue;
                }


                // Tìm vé đang hoạt động
                Ticket ticket =
                        ticketDAO.findActiveTicket(
                                vehicle.getId()
                        );


                if (ticket == null) {

                    System.out.println();

                    System.out.println(
                            "Xe khong co ve dang hoat dong!"
                    );

                    continue;
                }


                LocalDateTime entryTime =
                        ticket.getEntryTime();


                LocalDateTime exitTime =
                        LocalDateTime.now();


                long minutes =
                        Duration.between(
                                entryTime,
                                exitTime
                        ).toMinutes();


                // ==========================================
                // TÍNH PHÍ
                // ==========================================

                double fee;


                if (ticket.getPaymentType()
                        .equalsIgnoreCase("day")) {

                    fee =
                            ticketDAO.calculateDailyFee(
                                    entryTime,
                                    exitTime
                            );

                } else {

                    fee =
                            ticketDAO.calculateHourlyFee(
                                    entryTime,
                                    exitTime
                            );
                }


                // ==========================================
                // ĐÓNG VÉ
                // ==========================================

                boolean closed =
                        ticketDAO.closeTicket(
                                ticket.getId(),
                                exitTime,
                                fee
                        );


                if (closed) {

                    System.out.println();

                    System.out.println(
                            "================================"
                    );

                    System.out.println(
                            "        XE RA THANH CONG"
                    );

                    System.out.println(
                            "================================"
                    );


                    System.out.println(
                            "Bien so: "
                                    + vehicle.getLicensePlate()
                    );


                    System.out.println(
                            "Loai xe: "
                                    + vehicle.getVehicleType()
                    );


                    System.out.println(
                            "Chu xe: "
                                    + vehicle.getOwnerName()
                    );


                    System.out.println(
                            "Thoi gian vao: "
                                    + entryTime
                    );


                    System.out.println(
                            "Thoi gian ra: "
                                    + exitTime
                    );


                    System.out.println(
                            "Thoi gian gui: "
                                    + minutes
                                    + " phut"
                    );


                    System.out.println(
                            "Hinh thuc tinh phi: "
                                    + ticket.getPaymentType()
                    );


                    System.out.println(
                            "Tong tien: "
                                    + String.format(
                                    "%,.0f VND",
                                    fee
                            )
                    );


                    System.out.println(
                            "Ve da dong."
                    );


                } else {

                    System.out.println();

                    System.out.println(
                            "Khong the dong ve!"
                    );
                }
            }


            // ==========================================
            // 5. LỊCH SỬ VÉ
            // ==========================================

            else if (choice == 5) {

                ticketDAO.showTicketHistory();
            }


            // ==========================================
            // 6. TRẠNG THÁI CHỖ ĐỖ
            // ==========================================

            else if (choice == 6) {

                parkingDAO.showParkingSlots();
            }


            // ==========================================
            // 7. TÌM XE BẰNG CAMERA
            // ==========================================

            else if (choice == 7) {

                System.out.println();

                System.out.println(
                        "================================"
                );

                System.out.println(
                        "      TIM XE BANG CAMERA"
                );

                System.out.println(
                        "================================"
                );


                // Camera nhận diện biển số
                String licensePlate =
                        scanner.scanLicensePlate(sc);


                // Tìm xe trong database
                Vehicle vehicle =
                        parkingDAO.findVehicle(
                                licensePlate
                        );


                if (vehicle != null) {

                    System.out.println();

                    System.out.println(
                            "====== KET QUA NHAN DIEN ======"
                    );


                    System.out.println(
                            "Bien so: "
                                    + vehicle.getLicensePlate()
                    );


                    System.out.println(
                            "Loai xe: "
                                    + vehicle.getVehicleType()
                    );


                    System.out.println(
                            "Chu xe: "
                                    + vehicle.getOwnerName()
                    );


                    Ticket activeTicket =
                            ticketDAO.findActiveTicket(
                                    vehicle.getId()
                            );


                    if (activeTicket != null) {

                        System.out.println(
                                "Trang thai: DANG O TRONG BAI"
                        );


                        System.out.println(
                                "Gio vao: "
                                        + activeTicket.getEntryTime()
                        );

                    } else {

                        System.out.println(
                                "Trang thai: KHONG O TRONG BAI"
                        );
                    }


                } else {

                    System.out.println();

                    System.out.println(
                            "Khong tim thay bien so "
                                    + licensePlate
                                    + " trong he thong."
                    );
                }
            }


            // ==========================================
            // 8. THỐNG KÊ HỆ THỐNG
            // ==========================================

            else if (choice == 8) {

                parkingDAO.showStatistics();
            }


            // ==========================================
            // 0. ĐĂNG XUẤT
            // ==========================================

            else if (choice == 0) {

                System.out.println();

                System.out.println(
                        "================================"
                );

                System.out.println(
                        "       DANG XUAT THANH CONG"
                );

                System.out.println(
                        "================================"
                );
            }


            // ==========================================
            // LỰA CHỌN KHÔNG HỢP LỆ
            // ==========================================

            else {

                System.out.println();

                System.out.println(
                        "Lua chon khong hop le!"
                );
            }


        } while (choice != 0);


        sc.close();
    }
}