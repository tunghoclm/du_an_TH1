import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    private static final String URL =
            "jdbc:mysql://localhost:3306/smart_parking";

    private static final String USER = "root";

    private static final String PASSWORD = "hieudz12345";

    public static Connection getConnection() {

        try {
            Connection conn = DriverManager.getConnection(
                    URL,
                    USER,
                    PASSWORD
            );

            System.out.println("Ket noi MySQL thanh cong!");

            return conn;

        } catch (Exception e) {

            System.out.println("Ket noi MySQL that bai!");
            System.out.println("Loi: " + e.getMessage());

            return null;
        }
    }
}