-- ============================================
-- SMART PARKING
-- DATABASE HOÀN CHỈNH
-- ============================================

-- XÓA DATABASE CŨ
DROP DATABASE IF EXISTS smart_parking;

-- TẠO DATABASE MỚI
CREATE DATABASE smart_parking;

-- CHỌN DATABASE
USE smart_parking;


-- ============================================
-- 1. BẢNG USERS
-- Dùng cho chức năng đăng nhập
-- ============================================

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'staff'
);


-- TẠO TÀI KHOẢN
INSERT INTO users (username, password, role)
VALUES ('hieu', 'hieudz12345', 'admin');
insert into users( username, password, role)
values('tuat an','tuatan123', 'admin');

-- ============================================
-- 2. BẢNG VEHICLES
-- Lưu thông tin phương tiện
-- ============================================

CREATE TABLE vehicles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    license_plate VARCHAR(20) NOT NULL UNIQUE,
    vehicle_type VARCHAR(30) NOT NULL,
    owner_name VARCHAR(100) NOT NULL
);


-- ============================================
-- 3. BẢNG TICKETS
-- Quản lý vé xe vào / ra
-- ============================================

CREATE TABLE tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,

    vehicle_id INT NOT NULL,

    entry_time DATETIME NOT NULL,

    exit_time DATETIME NULL,

    fee DECIMAL(10,2) DEFAULT 0,

    payment_type VARCHAR(20) NOT NULL DEFAULT 'hour',

    FOREIGN KEY (vehicle_id)
        REFERENCES vehicles(id)
);


-- ============================================
-- KIỂM TRA CÁC BẢNG
-- ============================================

SHOW TABLES;


-- ============================================
-- KIỂM TRA USERS
-- ============================================

SELECT * FROM users;


-- ============================================
-- KIỂM TRA VEHICLES
-- ============================================

SELECT * FROM vehicles;


-- ============================================
-- KIỂM TRA TICKETS
-- ============================================

SELECT * FROM tickets;