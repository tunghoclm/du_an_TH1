"""
database.py
Lớp thao tác dữ liệu (Data Access Layer) cho hệ thống bãi đỗ xe thông minh.
Sử dụng SQLite - phù hợp cho demo, không cần cài đặt server DB riêng.

Bao gồm:
 - Lịch sử xe vào/ra (parking_records)
 - Sơ đồ vị trí đỗ xe theo khu A/B/C (parking_slots)
 - Người dùng hệ thống, đăng nhập (users)
 - Các hàm thống kê cho trang Thống kê
"""

import sqlite3
import os
from datetime import datetime, timedelta

BASE_DIR = os.path.dirname(__file__)
DB_PATH = os.path.join(BASE_DIR, 'parking.db')
SCHEMA_PATH = os.path.join(BASE_DIR, 'schema.sql')

AREAS = ['A', 'B', 'C']
SLOTS_PER_AREA = 20


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # cho phép truy cập cột theo tên
    return conn


def init_db():
    """Khởi tạo database theo file schema.sql, seed dữ liệu mẫu (vị trí đỗ, tài khoản)."""
    conn = get_connection()
    with open(SCHEMA_PATH, 'r', encoding='utf-8') as f:
        conn.executescript(f.read())

    # Migration nhẹ: nếu bảng parking_records cũ (từ bản trước) chưa có cột slot_name
    try:
        conn.execute("ALTER TABLE parking_records ADD COLUMN slot_name TEXT")
    except sqlite3.OperationalError:
        pass  # cột đã tồn tại

    conn.commit()

    # Seed 60 vị trí đỗ (A01..A20, B01..B20, C01..C20) nếu bảng đang trống
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) AS c FROM parking_slots")
    if cur.fetchone()['c'] == 0:
        rows = []
        for area in AREAS:
            for i in range(1, SLOTS_PER_AREA + 1):
                rows.append((f"{area}{i:02d}", area))
        conn.executemany(
            "INSERT INTO parking_slots (slot_name, area, status) VALUES (?, ?, 'available')",
            rows
        )
        conn.commit()

    # Seed tài khoản mặc định nếu bảng users đang trống
    cur.execute("SELECT COUNT(*) AS c FROM users")
    if cur.fetchone()['c'] == 0:
        default_users = [
            ('admin', 'Quản trị viên', '123456', 'admin', 'active'),
            ('nhanvien01', 'Nhân Viên 01', '123456', 'manager', 'active'),
        ]
        conn.executemany(
            "INSERT INTO users (username, fullname, password, role, status) VALUES (?, ?, ?, ?, ?)",
            default_users
        )
        conn.commit()

    conn.close()


# ============================================================
# LỊCH SỬ XE VÀO / RA
# ============================================================

def add_entry_record(plate_number: str, entry_image: str, slot_name: str = None) -> int:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        """INSERT INTO parking_records (plate_number, entry_time, entry_image, slot_name, status)
           VALUES (?, ?, ?, ?, 'IN')""",
        (plate_number, datetime.now().isoformat(timespec='seconds'), entry_image, slot_name)
    )
    conn.commit()
    record_id = cur.lastrowid
    conn.close()
    return record_id


def find_open_record(plate_number: str):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        """SELECT * FROM parking_records
           WHERE plate_number = ? AND status = 'IN'
           ORDER BY entry_time DESC LIMIT 1""",
        (plate_number,)
    )
    row = cur.fetchone()
    conn.close()
    return row


def close_record(record_id: int, exit_image: str, fee: int):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        """UPDATE parking_records
           SET exit_time = ?, exit_image = ?, fee = ?, status = 'OUT'
           WHERE id = ?""",
        (datetime.now().isoformat(timespec='seconds'), exit_image, fee, record_id)
    )
    conn.commit()
    conn.close()


def get_open_records():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM parking_records WHERE status = 'IN' ORDER BY entry_time DESC")
    rows = cur.fetchall()
    conn.close()
    return rows


def get_all_records():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM parking_records ORDER BY entry_time DESC")
    rows = cur.fetchall()
    conn.close()
    return rows


def count_open() -> int:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) AS c FROM parking_records WHERE status = 'IN'")
    n = cur.fetchone()['c']
    conn.close()
    return n


# ============================================================
# SƠ ĐỒ VỊ TRÍ ĐỖ XE
# ============================================================

def get_available_slots_by_area():
    """Trả về dict {area: [slot_row, ...]} chỉ gồm các vị trí đang trống — dùng cho trang xe vào chọn ô."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "SELECT * FROM parking_slots WHERE status = 'available' ORDER BY area, slot_name"
    )
    rows = cur.fetchall()
    conn.close()
    result = {a: [] for a in AREAS}
    for row in rows:
        result.setdefault(row['area'], []).append(row)
    return result


def is_slot_available(slot_name: str) -> bool:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT status FROM parking_slots WHERE slot_name = ?", (slot_name,))
    row = cur.fetchone()
    conn.close()
    return row is not None and row['status'] == 'available'


def get_all_slots():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM parking_slots ORDER BY area, slot_name")
    rows = cur.fetchall()
    conn.close()
    return rows


def find_free_slot(area: str = None):
    """Tìm 1 vị trí trống (ưu tiên theo khu nếu chỉ định). Trả về slot_name hoặc None."""
    conn = get_connection()
    cur = conn.cursor()
    if area:
        cur.execute(
            "SELECT slot_name FROM parking_slots WHERE status = 'available' AND area = ? ORDER BY slot_name LIMIT 1",
            (area,)
        )
    else:
        cur.execute(
            "SELECT slot_name FROM parking_slots WHERE status = 'available' ORDER BY area, slot_name LIMIT 1"
        )
    row = cur.fetchone()
    conn.close()
    return row['slot_name'] if row else None


def occupy_slot(slot_name: str, plate_number: str):
    conn = get_connection()
    conn.execute(
        "UPDATE parking_slots SET status = 'occupied', plate_number = ? WHERE slot_name = ?",
        (plate_number, slot_name)
    )
    conn.commit()
    conn.close()


def free_slot(slot_name: str):
    if not slot_name:
        return
    conn = get_connection()
    conn.execute(
        "UPDATE parking_slots SET status = 'available', plate_number = NULL WHERE slot_name = ?",
        (slot_name,)
    )
    conn.commit()
    conn.close()


def set_slot_maintenance(slot_name: str, in_maintenance: bool):
    conn = get_connection()
    new_status = 'maintenance' if in_maintenance else 'available'
    conn.execute(
        "UPDATE parking_slots SET status = ?, plate_number = NULL WHERE slot_name = ?",
        (new_status, slot_name)
    )
    conn.commit()
    conn.close()


def slot_counts():
    """Trả về dict {available, occupied, maintenance, total}."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT status, COUNT(*) AS c FROM parking_slots GROUP BY status")
    counts = {'available': 0, 'occupied': 0, 'maintenance': 0}
    for row in cur.fetchall():
        counts[row['status']] = row['c']
    counts['total'] = sum(counts.values())
    conn.close()
    return counts


def area_stats():
    """Trả về dict {area: {total, occupied, available, percent}} cho trang thống kê."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "SELECT area, status, COUNT(*) AS c FROM parking_slots GROUP BY area, status"
    )
    result = {a: {'total': 0, 'occupied': 0, 'available': 0, 'maintenance': 0} for a in AREAS}
    for row in cur.fetchall():
        area = row['area']
        result.setdefault(area, {'total': 0, 'occupied': 0, 'available': 0, 'maintenance': 0})
        result[area][row['status']] = row['c']
        result[area]['total'] += row['c']
    for area, data in result.items():
        data['percent'] = round((data['occupied'] / data['total'] * 100) if data['total'] else 0, 1)
    conn.close()
    return result


# ============================================================
# NGƯỜI DÙNG / ĐĂNG NHẬP
# ============================================================

def verify_login(username: str, password: str):
    """Trả về user row nếu đăng nhập đúng và tài khoản đang active, ngược lại None."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "SELECT * FROM users WHERE username = ? AND password = ?",
        (username, password)
    )
    row = cur.fetchone()
    conn.close()
    if row and row['status'] == 'active':
        return row
    return None


def get_user_by_id(user_id: int):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    row = cur.fetchone()
    conn.close()
    return row


def get_all_users():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users ORDER BY id")
    rows = cur.fetchall()
    conn.close()
    return rows


def username_exists(username: str) -> bool:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT 1 FROM users WHERE username = ?", (username,))
    exists = cur.fetchone() is not None
    conn.close()
    return exists


def add_user(username: str, fullname: str, password: str, role: str):
    conn = get_connection()
    conn.execute(
        "INSERT INTO users (username, fullname, password, role, status) VALUES (?, ?, ?, ?, 'active')",
        (username, fullname, password, role)
    )
    conn.commit()
    conn.close()


def toggle_user_status(user_id: int):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT status FROM users WHERE id = ?", (user_id,))
    row = cur.fetchone()
    if row:
        new_status = 'locked' if row['status'] == 'active' else 'active'
        conn.execute("UPDATE users SET status = ? WHERE id = ?", (new_status, user_id))
        conn.commit()
    conn.close()


def delete_user(user_id: int):
    conn = get_connection()
    conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
    conn.commit()
    conn.close()


# ============================================================
# THỐNG KÊ
# ============================================================

def get_statistics():
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) AS c FROM parking_records")
    total_records = cur.fetchone()['c']

    cur.execute("SELECT COUNT(*) AS c FROM parking_records WHERE status = 'IN'")
    total_in = cur.fetchone()['c']

    cur.execute("SELECT COUNT(*) AS c FROM parking_records WHERE status = 'OUT'")
    total_out = cur.fetchone()['c']

    cur.execute("SELECT COALESCE(SUM(fee), 0) AS s FROM parking_records WHERE status = 'OUT'")
    total_revenue = cur.fetchone()['s']

    today_str = datetime.now().strftime('%Y-%m-%d')
    cur.execute(
        "SELECT COUNT(*) AS c FROM parking_records WHERE substr(entry_time, 1, 10) = ?",
        (today_str,)
    )
    today_entries = cur.fetchone()['c']

    cur.execute(
        "SELECT COALESCE(SUM(fee), 0) AS s FROM parking_records "
        "WHERE status = 'OUT' AND substr(exit_time, 1, 10) = ?",
        (today_str,)
    )
    today_revenue = cur.fetchone()['s']

    conn.close()

    return {
        'total_records': total_records,
        'total_in': total_in,
        'total_out': total_out,
        'total_revenue': total_revenue,
        'today_entries': today_entries,
        'today_revenue': today_revenue,
    }
