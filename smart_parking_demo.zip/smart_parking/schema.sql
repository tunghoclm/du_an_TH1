-- schema.sql
-- Cơ sở dữ liệu cho hệ thống Bãi đỗ xe thông minh (bản ghép đầy đủ chức năng)

-- Bảng lịch sử xe vào/ra
CREATE TABLE IF NOT EXISTS parking_records (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    plate_number  TEXT NOT NULL,              -- Biển số xe (đã làm sạch, viết hoa)
    slot_name     TEXT,                       -- Vị trí đỗ được gán (vd: A01)
    entry_time    DATETIME NOT NULL,          -- Thời điểm xe vào
    exit_time     DATETIME,                   -- Thời điểm xe ra (NULL nếu còn trong bãi)
    entry_image   TEXT,                       -- Tên file ảnh chụp lúc vào
    exit_image    TEXT,                       -- Tên file ảnh chụp lúc ra
    fee           INTEGER,                    -- Phí gửi xe (VNĐ)
    status        TEXT NOT NULL DEFAULT 'IN'  -- 'IN' = đang gửi, 'OUT' = đã lấy xe
);

CREATE INDEX IF NOT EXISTS idx_plate_status ON parking_records (plate_number, status);

-- Bảng vị trí đỗ xe (sơ đồ bãi đỗ theo khu A/B/C)
CREATE TABLE IF NOT EXISTS parking_slots (
    slot_name     TEXT PRIMARY KEY,           -- vd: A01, B12, C05
    area          TEXT NOT NULL,              -- A, B, C
    status        TEXT NOT NULL DEFAULT 'available', -- available | occupied | maintenance
    plate_number  TEXT                        -- biển số đang đỗ tại vị trí này (nếu occupied)
);

-- Bảng người dùng hệ thống (đăng nhập, phân quyền)
CREATE TABLE IF NOT EXISTS users (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    username  TEXT UNIQUE NOT NULL,
    fullname  TEXT NOT NULL,
    password  TEXT NOT NULL,                  -- demo: lưu dạng plain text, thực tế nên hash
    role      TEXT NOT NULL DEFAULT 'user',   -- admin | manager | user
    status    TEXT NOT NULL DEFAULT 'active'  -- active | locked
);
