"""
app.py
Ứng dụng web Flask cho hệ thống Bãi đỗ xe thông minh (bản ghép đầy đủ chức năng).

Chức năng:
  /login, /logout   - Đăng nhập / đăng xuất
  /                  - Menu chính (trang chủ)
  /parking           - Sơ đồ bãi đỗ theo khu A/B/C (dữ liệu thật từ DB)
  /entry             - Xe vào bãi: upload ảnh -> OCR biển số -> gán vị trí -> lưu DB
  /exit              - Xe ra bãi : upload ảnh -> OCR biển số -> đối chiếu -> tính phí -> trả vị trí
  /history           - Lịch sử toàn bộ lượt gửi xe (có bộ lọc)
  /statistics        - Thống kê tổng quan
  /users             - Quản lý người dùng (chỉ admin)
"""

import os
import sys
import uuid
import functools
from datetime import datetime

# --- Kiểm tra thư viện cần thiết đã được cài đủ chưa ---
try:
    from flask import (
        Flask, render_template, request, redirect, url_for, flash, session
    )
    import cv2          # noqa: F401  (chỉ để kiểm tra đã cài opencv-python chưa)
    import easyocr       # noqa: F401  (chỉ để kiểm tra đã cài easyocr chưa)
except ImportError as e:
    print("=" * 60)
    print("LỖI: Thiếu thư viện cần thiết ->", e)
    print("Hãy chạy lệnh cài đặt trước khi chạy app.py:")
    print()
    print("   macOS/Linux:  ./setup.sh")
    print("   Windows    :  setup.bat")
    print()
    print("(hoặc thủ công: pip install -r requirements.txt)")
    print("=" * 60)
    sys.exit(1)

import database
from plate_recognition import recognize_plate

BASE_DIR = os.path.dirname(__file__)
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static', 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

FEE_PER_HOUR = 5000  # đơn giá gửi xe: 5.000 VNĐ / giờ (demo)

app = Flask(__name__)
app.secret_key = 'demo-smart-parking-secret-key'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

with app.app_context():
    database.init_db()


# ============================================================
# TIỆN ÍCH
# ============================================================

def save_upload(file_storage, prefix: str):
    ext = os.path.splitext(file_storage.filename)[1].lower() or '.jpg'
    filename = f"{prefix}_{uuid.uuid4().hex[:8]}{ext}"
    path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file_storage.save(path)
    return filename, path


def calc_fee(entry_time_str: str, exit_time: datetime):
    entry_time = datetime.fromisoformat(entry_time_str)
    duration = exit_time - entry_time
    total_seconds = duration.total_seconds()
    hours = int(total_seconds // 3600)
    if total_seconds % 3600 > 0:
        hours += 1
    hours = max(1, hours)
    return hours * FEE_PER_HOUR, duration


def login_required(view_func):
    @functools.wraps(view_func)
    def wrapped(*args, **kwargs):
        if 'user_id' not in session:
            flash('Vui lòng đăng nhập để tiếp tục.', 'error')
            return redirect(url_for('login'))
        return view_func(*args, **kwargs)
    return wrapped


def admin_required(view_func):
    @functools.wraps(view_func)
    def wrapped(*args, **kwargs):
        if session.get('role') != 'admin':
            flash('Chỉ quản trị viên mới có quyền truy cập trang này.', 'error')
            return redirect(url_for('index'))
        return view_func(*args, **kwargs)
    return wrapped


@app.context_processor
def inject_user():
    return {
        'current_user_fullname': session.get('fullname'),
        'current_user_role': session.get('role'),
    }


# ============================================================
# ĐĂNG NHẬP / ĐĂNG XUẤT
# ============================================================

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        user = database.verify_login(username, password)
        if user is None:
            flash('Sai tên đăng nhập, mật khẩu, hoặc tài khoản đã bị khóa.', 'error')
            return redirect(url_for('login'))

        session['user_id'] = user['id']
        session['username'] = user['username']
        session['fullname'] = user['fullname']
        session['role'] = user['role']

        flash(f'Xin chào {user["fullname"]}!', 'success')
        return redirect(url_for('index'))

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('Đã đăng xuất.', 'success')
    return redirect(url_for('login'))


# ============================================================
# TRANG CHỦ (MENU CHÍNH)
# ============================================================

@app.route('/')
@login_required
def index():
    counts = database.slot_counts()
    total_in = database.count_open()
    return render_template('index.html', counts=counts, total_in=total_in)


# ============================================================
# SƠ ĐỒ BÃI ĐỖ XE
# ============================================================

@app.route('/parking')
@login_required
def parking():
    slots = database.get_all_slots()
    slots_by_area = {'A': [], 'B': [], 'C': []}
    for slot in slots:
        slots_by_area.setdefault(slot['area'], []).append(slot)
    counts = database.slot_counts()
    return render_template('parking.html', slots_by_area=slots_by_area, counts=counts)


# ============================================================
# XE VÀO / XE RA (OCR BIỂN SỐ)
# ============================================================

@app.route('/entry', methods=['GET', 'POST'])
@login_required
def entry():
    if request.method == 'POST':
        file = request.files.get('image')
        chosen_slot = request.form.get('slot_name', '').strip()

        if not file or file.filename == '':
            flash('Vui lòng chọn ảnh chụp xe/biển số.', 'error')
            return redirect(url_for('entry'))

        if not chosen_slot:
            flash('Vui lòng chọn một vị trí đỗ.', 'error')
            return redirect(url_for('entry'))

        if not database.is_slot_available(chosen_slot):
            flash(f'Vị trí {chosen_slot} vừa có xe khác đỗ vào, vui lòng chọn vị trí khác.', 'error')
            return redirect(url_for('entry'))

        filename, path = save_upload(file, 'in')

        try:
            plate_text, _ = recognize_plate(path)
        except Exception as e:
            flash(f'Lỗi khi nhận diện biển số: {e}', 'error')
            return redirect(url_for('entry'))

        if not plate_text or len(plate_text) < 4:
            flash('Không nhận diện được biển số rõ ràng, vui lòng chụp lại (đủ sáng, ít góc nghiêng).', 'error')
            return redirect(url_for('entry'))

        if database.find_open_record(plate_text) is not None:
            flash(f'Xe {plate_text} đã có mặt trong bãi, chưa ra.', 'error')
            return redirect(url_for('entry'))

        # Kiểm tra lại lần cuối (tránh trường hợp 2 người cùng chọn 1 ô cùng lúc)
        if not database.is_slot_available(chosen_slot):
            flash(f'Vị trí {chosen_slot} vừa có xe khác đỗ vào, vui lòng chọn vị trí khác.', 'error')
            return redirect(url_for('entry'))

        database.add_entry_record(plate_text, filename, chosen_slot)
        database.occupy_slot(chosen_slot, plate_text)

        flash(f'✅ Xe vào bãi thành công! Biển số: {plate_text} — Vị trí: {chosen_slot}', 'success')
        return redirect(url_for('index'))

    slots_by_area = database.get_available_slots_by_area()
    return render_template('entry.html', slots_by_area=slots_by_area)


@app.route('/exit', methods=['GET', 'POST'])
@login_required
def exit_gate():
    if request.method == 'POST':
        file = request.files.get('image')
        if not file or file.filename == '':
            flash('Vui lòng chọn ảnh chụp xe/biển số.', 'error')
            return redirect(url_for('exit_gate'))

        filename, path = save_upload(file, 'out')

        try:
            plate_text, _ = recognize_plate(path)
        except Exception as e:
            flash(f'Lỗi khi nhận diện biển số: {e}', 'error')
            return redirect(url_for('exit_gate'))

        record = database.find_open_record(plate_text)
        if record is None:
            flash(f'⚠️ Không tìm thấy xe đang gửi với biển số "{plate_text or "(không rõ)"}".', 'error')
            return redirect(url_for('exit_gate'))

        now = datetime.now()
        fee, duration = calc_fee(record['entry_time'], now)
        database.close_record(record['id'], filename, fee)
        database.free_slot(record['slot_name'])

        flash(
            f'✅ Xe {plate_text} đã ra bãi (vị trí {record["slot_name"] or "?"}). '
            f'Thời gian gửi: {duration}. Phí: {fee:,} VNĐ',
            'success'
        )
        return redirect(url_for('index'))

    return render_template('exit.html')


# ============================================================
# LỊCH SỬ
# ============================================================

@app.route('/history')
@login_required
def history():
    keyword = request.args.get('plate', '').strip().upper()
    status_filter = request.args.get('status', 'all')
    date_filter = request.args.get('date', '')

    records = database.get_all_records()

    in_count = sum(1 for r in records if r['status'] == 'IN')
    out_count = sum(1 for r in records if r['status'] == 'OUT')
    today_str = datetime.now().strftime('%Y-%m-%d')
    today_count = sum(1 for r in records if (r['entry_time'] or '').startswith(today_str))

    def matches(r):
        if keyword and keyword not in (r['plate_number'] or '').upper():
            return False
        if status_filter != 'all' and r['status'] != status_filter:
            return False
        if date_filter and not (r['entry_time'] or '').startswith(date_filter):
            return False
        return True

    filtered = [r for r in records if matches(r)]

    return render_template(
        'history.html',
        records=filtered,
        keyword=keyword,
        status_filter=status_filter,
        date_filter=date_filter,
        total_count=len(records),
        in_count=in_count,
        out_count=out_count,
        today_count=today_count,
    )


# ============================================================
# THỐNG KÊ
# ============================================================

@app.route('/statistics')
@login_required
def statistics():
    stats = database.get_statistics()
    slot_stats = database.slot_counts()
    area_stats = database.area_stats()
    return render_template('statistics.html', stats=stats, slot_stats=slot_stats, area_stats=area_stats)


# ============================================================
# QUẢN LÝ NGƯỜI DÙNG (CHỈ ADMIN)
# ============================================================

@app.route('/users')
@login_required
@admin_required
def users():
    all_users = database.get_all_users()
    return render_template('users.html', users=all_users)


@app.route('/users/add', methods=['POST'])
@login_required
@admin_required
def add_user():
    username = request.form.get('username', '').strip()
    fullname = request.form.get('fullname', '').strip()
    password = request.form.get('password', '')
    role = request.form.get('role', 'user')

    if not username or not fullname or not password:
        flash('Vui lòng nhập đầy đủ thông tin.', 'error')
        return redirect(url_for('users'))

    if database.username_exists(username):
        flash('Tên đăng nhập đã tồn tại.', 'error')
        return redirect(url_for('users'))

    database.add_user(username, fullname, password, role)
    flash(f'Đã thêm người dùng "{username}".', 'success')
    return redirect(url_for('users'))


@app.route('/users/<int:user_id>/toggle', methods=['POST'])
@login_required
@admin_required
def toggle_user(user_id):
    target = database.get_user_by_id(user_id)
    if target and target['username'] == 'admin':
        flash('Không thể khóa tài khoản admin.', 'error')
        return redirect(url_for('users'))
    database.toggle_user_status(user_id)
    flash('Đã cập nhật trạng thái tài khoản.', 'success')
    return redirect(url_for('users'))


@app.route('/users/<int:user_id>/delete', methods=['POST'])
@login_required
@admin_required
def remove_user(user_id):
    target = database.get_user_by_id(user_id)
    if target and target['username'] == 'admin':
        flash('Không thể xóa tài khoản admin.', 'error')
        return redirect(url_for('users'))
    database.delete_user(user_id)
    flash('Đã xóa người dùng.', 'success')
    return redirect(url_for('users'))


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
